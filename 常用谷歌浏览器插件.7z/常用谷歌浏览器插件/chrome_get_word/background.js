﻿/**
 * @author Dongxu Huang, Shu Ke, Wang Lei, Lu Yuan
 * @date   2015-02-02
 */

function GetSynchronizedRequestText(url) {
  try {
    var request = new XMLHttpRequest();
    request.open('GET', url, false);
    request.send();
    if (request.status == 200 && request.readyState == 4) {
      return request.responseText || '';
    }
  } catch(ex) {
    return null;
  }
  return null;
}

setTimeout(function () {
  if (IsNewVersion()) {
    setInterval(function () {
	    PumpMsg();
    }, 200);
  } else {
    PumpMsg();
  }
}, 1500);
if (IsNewVersion()) {
  setInterval(function () {
    if (!hostConnected && !disconnectForever) {
      connect();
    } else if (port) {
      postMessage({
        'screen_word_capturing_state': 1,
        'testing': 1
      });
    }
  }, 2000);
}
var lastTimeStamp;
var browserName = "";
 
INIT();

var port = null;
var hostConnected = false;
var disconnectForever = false;
var newClientInstalled = false;
var newClientRunning = false;
const mininalNewClientVersion = '6.3.66.3250';
var runningClientVersion;
var screenWordCapturingEnabled = false;
var oldClient = true;

function postMessage(message) {
  if (!port)
    return;
  try {
    var err;
    port.postMessage(message);
  } catch (ex) {
    err = ex;
  }
  if (err) {
    port = null;
    hostConnected = false;
  }
}

function connect() {
  if (port || (!IsNewVersion() && !IsLBBrowser()))
    return;
  var host = 'com.youdao.cidian.text_extractor_host';
  port = chrome.runtime.connectNative(host);
  port.onMessage.addListener(onNativeMessage);
  port.onDisconnect.addListener(onDisconnect);
  port.postMessage({
    'browser': IsLBBrowser() ? 'liebao' : 'chrome',
    'version': chrome.runtime.getManifest().version,
    'screen_word_capturing_state': 1,
    'testing': 1
  });
}

window.addEventListener('unload', function (e) {
  disconnect();
}, false);

function disconnect() {
  if (port) {
    port.disconnect();
    port = null;
    hostConnected = false;
  }
}

function onNativeMessage(response) {
  if (typeof response != 'object')
    return;
  hostConnected = true;
  if (response['new_client_installed']) {
    UpdateClientInfo(response);
  } if (response['screen_word_capturing_state']) {
    UpdateScreenWordCapturingState(response);
  } if (response['should_disconnect_forever']) {
    console.log('should_disconnect_forever', disconnectForever);
    disconnectForever = true;
    disconnect();
  } else {
    var timestamp = response['timestamp'];
    if (!timestamp || typeof timestamp != 'string')
      return;
    checkSetting(timestamp);
  }
}

function onDisconnect(response) {
  console.log('disconnect', response, JSON.stringify(response));
  port = null;
  hostConnected = false;
}

function GetBrowserMajorVersion() {
  var ver = navigator.userAgent.match(/(?:chrome\/)([\d.]+)/i);
  if (!ver || !ver[1])
    return;
  var major = ver[1];
  if (!major)
    return;
  return major.split('.')[0];
}

function IsLBBrowser() {
  var lbBrowser = navigator.userAgent.match(/lbbrowser/i);
  if (!lbBrowser || !lbBrowser[0])
    return false;
  return lbBrowser[0].toLowerCase() == 'lbbrowser';
}

function IsNewVersion() {
  var v = GetBrowserMajorVersion();
  return v && v >= 37;
}

function UpdateScreenWordCapturingState(response) {
  if (response && typeof response == 'object')
    screenWordCapturingEnabled = response['screen_word_capturing_state'];
}

function UpdateClientInfo(response) {
  if (response && typeof response == 'object') {//console.log('res',response);
    screenWordCapturingEnabled = response['screen_word_capturing_state'];
    if (response['new_client_installed']) {
      newClientInstalled = !!response['new_client_installed'];
    }
    newClientRunning = false;
    runningClientVersion = response['running_client_version'];
    if (runningClientVersion) {
      var mininalNewClientVersionArray = mininalNewClientVersion.split('.');
      var runningClientVersionArray = runningClientVersion.split('.');
      mininalNewClientVersionArray.forEach(function (element, index) {
        if (newClientRunning)
          return;
        if (runningClientVersionArray[index] > element) {
          newClientRunning = true;
          return;
        }
      });
    }
    if (!newClientRunning) {
      disconnect();
    }
  }
}

function INIT() {
  var xhr = new XMLHttpRequest();
  xhr.onreadystatechange = function(data) {
        if (xhr.readyState == 4) {
 	      	  lastTimeStamp = xhr.responseText.split(" ")[1];
        }
  }
  var url = chrome.extension.getURL("flg.txt") +'#'+ new Date().getTime();
  xhr.open('GET', url, true);
  xhr.send();
}

function PumpMsg()
{
  if (!hostConnected) {
    if (port)
      port.postMessage({ 'timestamp': 1 });
  } else if (newClientRunning && screenWordCapturingEnabled) {
    postMessage({ 'timestamp': 1 });
  }
  if (!hostConnected && !port) {
      try {
        var flg_req = new XMLHttpRequest();
        var flg_url = chrome.extension.getURL("flg.txt") +'#'+ new Date().getTime();
        flg_req.open('GET', flg_url, false);
        flg_req.send();
        if (flg_req.status == 200 && flg_req.readyState == 4) {
          checkSetting(flg_req.responseText);
          return;
        }
      } catch(ex) {
    }
  }
}

function GetTimestampFromData(data) {
  
}

function checkSetting(text)
{
	var param = text.split(" ");
	var msg =  param[0];
	var time = param[1];
	if (param.length > 2) {
		browserName = param[2];
	}
	if (time != lastTimeStamp) {
		if (msg == "GETWORD") {
      		chrome.tabs.getSelected(null, function(tab) {
				chrome.tabs.sendRequest(tab.id, {'action' : "onmsg"}, function(response) {
				});
			});
		}
		lastTimeStamp = time;
	}
  if (!hostConnected && !port && !IsNewVersion()) {
  	setTimeout(function () {
  		PumpMsg();
  	}, 200);
  }
}

function sendToDict(url) {
    url += 'src=' + browserName + '&';
    var xhr = new XMLHttpRequest();
    xhr.open('GET', url, true);
    xhr.send();
}

function sendWord(word, offset) {
    var url = 'http://127.0.0.1:50000/word='+word+'&offset='+offset+'&';
    sendToDict(url);
}

function sendStrokeWord(word)
{
    var url = 'http://127.0.0.1:50000/word='+word+'&isstroke=true&';
    sendToDict(url);
}

setInterval(function () {
    var url = 'http://127.0.0.1:50000/word=test&heartbeating=true&'; 
    sendToDict(url);
}, 120000);

chrome.extension.onRequest.addListener(function(request, sender, sendResponse) {
  if (request.action == "word") {
    if (request.msg != "") {
	    sendWord(request.msg, request.offset);
    }
  } else if (request.action == "stroke") {
    sendStrokeWord(request.msg);
  }
});